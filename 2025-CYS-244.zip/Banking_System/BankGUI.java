import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.function.Consumer;

public class BankGUI {

    private static final Color BG=new Color(240,253,244),SB=new Color(20,83,45),AC=new Color(22,163,74),
        WH=Color.WHITE,RD=new Color(220,38,38),BL=new Color(37,99,235),TX=new Color(15,23,42);
    private static final Font FN=new Font("SansSerif",Font.PLAIN,13),FB=new Font("SansSerif",Font.BOLD,13),
        FT=new Font("SansSerif",Font.BOLD,22),FH=new Font("SansSerif",Font.BOLD,18),FI=new Font("SansSerif",Font.BOLD,26);
    private static final Border FLD=BorderFactory.createCompoundBorder(
        new LineBorder(new Color(167,243,208),1,true),new EmptyBorder(7,11,7,11));

    private final JFrame win;
    private final Bank bank;
    private final CardLayout cards=new CardLayout();
    private final JPanel content=new JPanel(cards);

    private JLabel lBank,lClients,lAccounts,lFunds,toast;
    private DefaultTableModel dashModel,clientModel,accountModel;
    private Timer toastTimer;
    private JButton activeNav;

    private final JComboBox<String> clientDrop=drop(),depositDrop=drop(),withdrawDrop=drop(),removeDrop=drop();

    public static void main(String[] args) {
        SwingUtilities.invokeLater(()->{
            String name=JOptionPane.showInputDialog(null,"Enter bank name:","Bank Management System",JOptionPane.PLAIN_MESSAGE);
            if(name==null||name.isBlank()){JOptionPane.showMessageDialog(null,"Bank name cannot be empty!");System.exit(0);}
            Bank b=new Bank(name.trim());boolean loaded=b.loadFromFile();
            BankGUI gui=new BankGUI(b);gui.show();
            gui.toast(loaded?"Data loaded successfully.":"New bank created: "+name,loaded?"success":"info");
        });
    }

    public BankGUI(Bank bank) {
        this.bank=bank;
        win=new JFrame("Bank Management System — "+bank.getName());
        win.setSize(1080,680);win.setMinimumSize(new Dimension(920,560));
        win.setLocationRelativeTo(null);win.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        win.addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){bank.saveToFile();System.exit(0);}});
        win.setLayout(new BorderLayout());
        win.add(buildSidebar(),BorderLayout.WEST);
        content.setBackground(BG);
        content.add(buildDashboard(),"dashboard");
        content.add(buildAddClient(),"addClient");
        content.add(buildOpenAccount(),"openAccount");
        content.add(buildTransaction("Deposit","Deposit",AC,true),"deposit");
        content.add(buildTransaction("Withdraw","Withdraw",RD,false),"withdraw");
        content.add(buildTablePage("All Clients",new String[]{"Client ID","Name","CNIC","Phone","Accounts","Total Balance"},m->clientModel=m,this::refreshClients),"viewClients");
        content.add(buildTablePage("All Accounts",new String[]{"Account No.","Holder Name","Balance"},m->accountModel=m,this::refreshAccounts),"viewAccounts");
        content.add(buildSearch(),"search");
        content.add(buildRemoveClient(),"removeClient");
        win.add(content,BorderLayout.CENTER);
        show("dashboard");refreshDashboard();
    }

    public void show(){win.setVisible(true);}
    private void show(String p){cards.show(content,p);}

    private JPanel buildSidebar() {
        JPanel p=new JPanel();p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
        p.setBackground(SB);p.setPreferredSize(new Dimension(215,0));p.setBorder(new EmptyBorder(20,0,20,0));
        JLabel icon=new JLabel("$",SwingConstants.CENTER);icon.setFont(FI);icon.setForeground(new Color(134,239,172));icon.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel bn=new JLabel(bank.getName(),SwingConstants.CENTER);bn.setFont(FB);bn.setForeground(WH);bn.setAlignmentX(Component.CENTER_ALIGNMENT);bn.setBorder(new EmptyBorder(2,10,16,10));
        JSeparator sep=new JSeparator();sep.setForeground(new Color(34,197,94,80));sep.setMaximumSize(new Dimension(215,1));
        p.add(icon);p.add(bn);p.add(sep);p.add(Box.createVerticalStrut(8));
        for(String[]i:new String[][]{{"  Dashboard","dashboard"},{"  Add Client","addClient"},{"  Open Account","openAccount"},
            {"  Deposit","deposit"},{"  Withdraw","withdraw"},{"  View Clients","viewClients"},
            {"  View Accounts","viewAccounts"},{"  Search","search"},{"  Remove Client","removeClient"}})
            p.add(navBtn(i[0],i[1]));
        p.add(Box.createVerticalGlue());return p;
    }

    private JButton navBtn(String label,String page) {
        JButton b=new JButton(label);b.setFont(FN);b.setForeground(new Color(134,239,172));b.setBackground(SB);
        b.setBorderPainted(false);b.setFocusPainted(false);b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setMaximumSize(new Dimension(215,40));b.setBorder(new EmptyBorder(8,18,8,10));b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter(){
            public void mouseEntered(MouseEvent e){if(b!=activeNav){b.setBackground(new Color(21,128,61));b.setForeground(WH);}}
            public void mouseExited(MouseEvent e){if(b!=activeNav){b.setBackground(SB);b.setForeground(new Color(134,239,172));}}
        });
        b.addActionListener(e->{
            if(activeNav!=null){activeNav.setBackground(SB);activeNav.setForeground(new Color(134,239,172));}
            activeNav=b;b.setBackground(AC);b.setForeground(WH);show(page);
            switch(page){
                case"dashboard"->refreshDashboard();case"viewClients"->refreshClients();
                case"viewAccounts"->refreshAccounts();case"openAccount"->refreshClientDrop(clientDrop);
                case"deposit"->refreshAccDrop(depositDrop);case"withdraw"->refreshAccDrop(withdrawDrop);
                case"removeClient"->refreshClientDrop(removeDrop);
            }
        });
        return b;
    }

    private JPanel buildDashboard() {
        JPanel outer=new JPanel(new BorderLayout());outer.setBackground(BG);
        toast=new JLabel(" ");toast.setFont(FN);toast.setPreferredSize(new Dimension(0,34));toast.setVisible(false);
        outer.add(toast,BorderLayout.NORTH);
        JPanel main=new JPanel();main.setLayout(new BoxLayout(main,BoxLayout.Y_AXIS));main.setBackground(BG);main.setBorder(new EmptyBorder(22,30,22,30));
        JLabel h=new JLabel("Dashboard");h.setFont(FT);h.setForeground(new Color(20,83,45));h.setAlignmentX(Component.LEFT_ALIGNMENT);h.setBorder(new EmptyBorder(0,0,18,0));
        main.add(h);
        JPanel mx=new JPanel(new GridLayout(1,4,14,0));mx.setBackground(BG);mx.setMaximumSize(new Dimension(Integer.MAX_VALUE,110));mx.setAlignmentX(Component.LEFT_ALIGNMENT);
        lBank=metric("Bank",bank.getName(),mx);lClients=metric("Total Clients","0",mx);
        lAccounts=metric("Total Accounts","0",mx);lFunds=metric("Total Funds","Rs.0.00",mx);
        main.add(mx);main.add(Box.createVerticalStrut(18));
        dashModel=noEdit(new String[]{"Client ID","Name","CNIC","Phone","Accounts","Total Balance"});
        JPanel tc=new JPanel(new BorderLayout());tc.setBackground(WH);tc.setBorder(new EmptyBorder(15,15,15,15));tc.setAlignmentX(Component.LEFT_ALIGNMENT);
        tc.add(new JScrollPane(styledTable(dashModel)));main.add(tc);outer.add(main,BorderLayout.CENTER);return outer;
    }

    private void refreshDashboard() {
        if(lClients==null)return;
        lBank.setText(bank.getName());lClients.setText(""+bank.getClList().size());
        lAccounts.setText(""+bank.getAcList().size());lFunds.setText(rs(bank.totalAmount()));
        dashModel.setRowCount(0);
        for(Client c:bank.getClList())dashModel.addRow(new Object[]{c.getID(),c.getPersondetails().getName(),
            c.getPersondetails().getCNIC(),c.getPersondetails().getPhoneNo(),c.getAccountlist().size(),rs(c.totalAmount())});
    }

    private JPanel buildAddClient() {
        return buildForm("Add Client",new String[]{"Full Name","CNIC","Phone No"},"Register Client",AC,fields->{
            String name=fields[0].getText().trim(),cnic=fields[1].getText().trim(),phone=fields[2].getText().trim();
            if(name.isEmpty()||cnic.isEmpty()||phone.isEmpty()){toast("All fields are required.","error");return;}
            try{bank.addClient(new Person(name,cnic,phone));toast("Client registered.","success");
                for(JTextField f:fields)f.setText("");refreshDashboard();refreshClientDrop(clientDrop);}
            catch(Exception ex){toast(ex.getMessage(),"error");}
        });
    }

    private JPanel buildOpenAccount() {
        JPanel outer=page("Open Account"),form=new JPanel(new GridBagLayout());
        form.setBackground(WH);form.setBorder(new EmptyBorder(15,15,15,15));
        GridBagConstraints g=gbc();JTextField amt=field();JLabel st=new JLabel(" ");
        addRow(form,g,0,"Select Client",clientDrop);addRow(form,g,1,"Opening Balance (Rs.)",amt);
        JButton b=btn("Open Account",AC);g.gridx=1;g.gridy=2;form.add(b,g);g.gridy=3;form.add(st,g);
        b.addActionListener(e->{
            String sel=(String)clientDrop.getSelectedItem(),amtTxt=amt.getText().trim();
            if(sel==null||sel.equals("— No clients yet —")){st.setText("No clients available.");st.setForeground(RD);return;}
            if(amtTxt.isEmpty()){st.setText("Enter opening balance.");st.setForeground(RD);return;}
            try{
                String id=sel.substring(sel.lastIndexOf("(")+1,sel.lastIndexOf(")"));
                Account ac=bank.addAccount(null,Float.parseFloat(amtTxt),bank.getClientById(id));
                st.setText("Account opened: "+ac.getNumber());st.setForeground(AC);toast("Account opened!","success");
                amt.setText("");refreshDashboard();refreshClientDrop(clientDrop);refreshAccDrop(depositDrop);refreshAccDrop(withdrawDrop);
            }catch(NumberFormatException ex){st.setText("Invalid amount.");st.setForeground(RD);}
            catch(Exception ex){st.setText(ex.getMessage());st.setForeground(RD);}
        });
        outer.add(form,BorderLayout.CENTER);return outer;
    }

    private JPanel buildTransaction(String title,String btnLabel,Color color,boolean isDeposit) {
        JPanel outer=page(title),form=new JPanel(new GridBagLayout());
        form.setBackground(WH);form.setBorder(new EmptyBorder(15,15,15,15));
        GridBagConstraints g=gbc();JComboBox<String>dr=isDeposit?depositDrop:withdrawDrop;
        JTextField amt=field();JLabel st=new JLabel(" ");
        addRow(form,g,0,"Select Account",dr);addRow(form,g,1,"Amount (Rs.)",amt);
        JButton b=btn(btnLabel,color);g.gridx=1;g.gridy=2;form.add(b,g);g.gridy=3;form.add(st,g);
        b.addActionListener(e->{
            String sel=(String)dr.getSelectedItem(),amtTxt=amt.getText().trim();
            if(sel==null||sel.equals("— No accounts yet —")){st.setText("No accounts available.");st.setForeground(RD);return;}
            if(amtTxt.isEmpty()){st.setText("Enter an amount.");st.setForeground(RD);return;}
            try{
                String acNo=sel.split("  —  ")[0].trim();float a=Float.parseFloat(amtTxt);
                if(isDeposit)bank.deposit(acNo,a);else bank.withdraw(acNo,a);
                st.setText("Transaction completed.");st.setForeground(AC);amt.setText("");
                refreshDashboard();refreshAccDrop(depositDrop);refreshAccDrop(withdrawDrop);
            }catch(NumberFormatException ex){st.setText("Invalid amount.");st.setForeground(RD);}
            catch(Exception ex){st.setText(ex.getMessage());st.setForeground(RD);}
        });
        outer.add(form,BorderLayout.CENTER);return outer;
    }

    private JPanel buildTablePage(String title,String[]cols,Consumer<DefaultTableModel>ms,Runnable ref) {
        JPanel outer=page(title);DefaultTableModel m=noEdit(cols);ms.accept(m);
        JButton r=btn("Refresh",AC);r.addActionListener(e->ref.run());
        JPanel c=new JPanel(new BorderLayout());c.setBackground(WH);
        c.add(r,BorderLayout.NORTH);c.add(new JScrollPane(styledTable(m)),BorderLayout.CENTER);
        outer.add(c,BorderLayout.CENTER);return outer;
    }

    private void refreshClients() {
        if(clientModel==null)return;clientModel.setRowCount(0);
        for(Client c:bank.getClList())clientModel.addRow(new Object[]{c.getID(),c.getPersondetails().getName(),
            c.getPersondetails().getCNIC(),c.getPersondetails().getPhoneNo(),c.getAccountlist().size(),rs(c.totalAmount())});
    }

    private void refreshAccounts() {
        if(accountModel==null)return;accountModel.setRowCount(0);
        for(Account a:bank.getAcList())accountModel.addRow(new Object[]{a.getNumber(),
            a.getAcHolder()!=null?a.getAcHolder().getPersondetails().getName():"Unknown",rs(a.getAmount())});
    }

    private JPanel buildSearch() {
        JPanel outer=page("Search"),stack=new JPanel(new GridLayout(2,1,0,14));stack.setBackground(BG);
        stack.add(searchPanel("Search Client by CNIC",false));
        stack.add(searchPanel("Search Account Number",true));
        outer.add(stack,BorderLayout.CENTER);return outer;
    }

    private JPanel searchPanel(String btnLabel,boolean isAccount) {
        JPanel p=new JPanel(new GridBagLayout());p.setBackground(WH);p.setBorder(new EmptyBorder(15,15,15,15));
        GridBagConstraints g=gbc();JTextField f=field();JLabel res=new JLabel(" ");JButton b=btn(btnLabel,AC);
        g.gridx=0;g.gridy=0;g.weightx=0.7;p.add(f,g);g.gridx=1;g.weightx=0.3;p.add(b,g);
        g.gridx=0;g.gridy=1;g.gridwidth=2;p.add(res,g);
        b.addActionListener(e->{
            if(isAccount){
                Account ac=bank.searchAccount(f.getText().trim().toUpperCase());
                res.setText(ac==null?"Not found.":ac.getNumber()+" | Balance: "+rs(ac.getAmount()));res.setForeground(ac==null?RD:AC);
            }else{
                Client cl=bank.searchCustomerDetail(f.getText().trim());
                res.setText(cl==null?"Not found.":cl.getID()+" | "+cl.getPersondetails().getName()+" | Total: "+rs(cl.totalAmount()));res.setForeground(cl==null?RD:AC);
            }
        });
        return p;
    }

    private JPanel buildRemoveClient() {
        JPanel outer=page("Remove Client"),form=new JPanel(new GridBagLayout());
        form.setBackground(WH);form.setBorder(new EmptyBorder(15,15,15,15));
        GridBagConstraints g=gbc();addRow(form,g,0,"Select Client",removeDrop);
        JButton b=btn("Delete Client",RD);g.gridx=1;g.gridy=1;form.add(b,g);
        b.addActionListener(e->{
            String sel=(String)removeDrop.getSelectedItem();
            if(sel==null||sel.equals("— No clients yet —"))return;
            String id=sel.substring(sel.lastIndexOf("(")+1,sel.lastIndexOf(")"));
            if(JOptionPane.showConfirmDialog(win,"Delete client "+id+"?","Confirm",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;
            if(bank.removeClient(id)){toast("Client removed.","info");refreshDashboard();refreshClients();refreshAccounts();
                refreshClientDrop(clientDrop);refreshClientDrop(removeDrop);refreshAccDrop(depositDrop);refreshAccDrop(withdrawDrop);}
        });
        outer.add(form,BorderLayout.CENTER);return outer;
    }

    private JPanel buildForm(String title,String[]labels,String btnText,Color color,Consumer<JTextField[]>action) {
        JPanel outer=page(title),form=new JPanel(new GridBagLayout());
        form.setBackground(WH);form.setBorder(new EmptyBorder(15,15,15,15));
        GridBagConstraints g=gbc();JTextField[]fields=new JTextField[labels.length];
        for(int i=0;i<labels.length;i++){fields[i]=field();addRow(form,g,i,labels[i],fields[i]);}
        JButton b=btn(btnText,color);g.gridx=1;g.gridy=labels.length;form.add(b,g);
        b.addActionListener(e->action.accept(fields));outer.add(form,BorderLayout.CENTER);return outer;
    }

    private void addRow(JPanel form,GridBagConstraints g,int row,String label,JComponent comp) {
        g.gridx=0;g.gridy=row;g.weightx=0.2;form.add(new JLabel(label),g);
        g.gridx=1;g.weightx=0.8;form.add(comp,g);
    }

    private void refreshClientDrop(JComboBox<String>d) {
        d.removeAllItems();
        if(bank.getClList().isEmpty()){d.addItem("— No clients yet —");return;}
        for(Client c:bank.getClList())d.addItem(c.getPersondetails().getName()+"  ("+c.getID()+")");
    }

    private void refreshAccDrop(JComboBox<String>d) {
        d.removeAllItems();
        if(bank.getAcList().isEmpty()){d.addItem("— No accounts yet —");return;}
        for(Account a:bank.getAcList()){
            String name=a.getAcHolder()!=null?a.getAcHolder().getPersondetails().getName():"Unknown";
            d.addItem(a.getNumber()+"  —  "+name+"  ("+rs(a.getAmount())+")");
        }
    }

    public void toast(String msg,String type) {
        if(toast==null)return;
        toast.setText("   "+msg);toast.setForeground(WH);toast.setOpaque(true);
        toast.setBackground("success".equals(type)?new Color(21,128,61):"info".equals(type)?BL:RD);
        toast.setVisible(true);
        if(toastTimer!=null)toastTimer.stop();
        toastTimer=new Timer(2800,e->toast.setVisible(false));toastTimer.setRepeats(false);toastTimer.start();
    }

    private JPanel page(String title) {
        JPanel p=new JPanel(new BorderLayout());p.setBackground(BG);p.setBorder(new EmptyBorder(26,30,26,30));
        JLabel h=new JLabel(title);h.setFont(FT);h.setForeground(new Color(20,83,45));h.setBorder(new EmptyBorder(0,0,18,0));
        p.add(h,BorderLayout.NORTH);return p;
    }

    private JTextField field(){JTextField f=new JTextField();f.setFont(FN);f.setBackground(new Color(249,250,251));f.setForeground(TX);f.setBorder(FLD);f.setPreferredSize(new Dimension(0,38));return f;}
    private JComboBox<String> drop(){JComboBox<String>cb=new JComboBox<>();cb.setFont(FN);cb.setBackground(new Color(249,250,251));cb.setBorder(new LineBorder(new Color(167,243,208),1,true));cb.setPreferredSize(new Dimension(0,38));return cb;}
    private JButton btn(String t,Color bg){JButton b=new JButton(t);b.setFont(FB);b.setBackground(bg);b.setForeground(WH);b.setBorderPainted(false);b.setFocusPainted(false);b.setOpaque(true);b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));b.setBorder(new EmptyBorder(9,24,9,24));return b;}
    private String rs(double v){return"Rs."+String.format("%.2f",v);}
    private DefaultTableModel noEdit(String[]cols){return new DefaultTableModel(cols,0){public boolean isCellEditable(int r,int c){return false;}};}
    private GridBagConstraints gbc(){GridBagConstraints g=new GridBagConstraints();g.fill=GridBagConstraints.HORIZONTAL;g.insets=new Insets(8,8,8,8);return g;}

    private JLabel metric(String label,String val,JPanel p) {
        JPanel card=new JPanel(new BorderLayout());card.setBackground(WH);card.setBorder(new EmptyBorder(10,10,10,10));
        JLabel v=new JLabel(val);v.setFont(FH);card.add(new JLabel(label),BorderLayout.NORTH);card.add(v,BorderLayout.CENTER);p.add(card);return v;
    }

    private JTable styledTable(DefaultTableModel m) {
        JTable t=new JTable(m);t.setFont(FN);t.setRowHeight(34);t.setShowGrid(false);
        t.setSelectionBackground(new Color(187,247,208));t.setSelectionForeground(TX);
        t.getTableHeader().setFont(FB);t.getTableHeader().setBackground(new Color(220,252,231));
        t.setDefaultRenderer(Object.class,new DefaultTableCellRenderer(){
            public Component getTableCellRendererComponent(JTable tbl,Object v,boolean sel,boolean foc,int r,int c){
                super.getTableCellRendererComponent(tbl,v,sel,foc,r,c);setBorder(new EmptyBorder(0,14,0,14));
                if(!sel)setBackground(r%2==0?WH:BG);return this;}});
        return t;
    }
}
