import java.io.*;
import java.util.ArrayList;

public class Bank implements Serializable {
    private String name;
    private ArrayList<Client> clList;
    private ArrayList<Account> acList;

    public Bank(String name) {
        this.name = name;
        this.clList = new ArrayList<>();
        this.acList = new ArrayList<>();
    }

    public String getName() { return name; }
    public ArrayList<Client> getClList() { return clList; }
    public ArrayList<Account> getAcList() { return acList; }

    public Client addClient(Person p) {
        Client c = new Client(null, p);
        clList.add(c);
        saveToFile();
        return c;
    }

    public Account addAccount(String number, float amount, Client c) {
        Account a = new Account(number, amount, c);
        c.addAccount(a);
        acList.add(a);
        saveToFile();
        return a;
    }

    public Account searchAccount(String id) {
        for (Account a : acList) {
            if (a.getNumber().equalsIgnoreCase(id)) return a;
        }
        return null;
    }

    public Client getClientById(String id) {
        for (Client c : clList) {
            if (c.getID().equals(id)) return c;
        }
        return null;
    }

    public boolean removeClient(String id) {
        Client toRemove = null;
        for (Client c : clList) {
            if (c.getID().equals(id)) {
                toRemove = c;
                break;
            }
        }
        if (toRemove != null) {
            acList.removeAll(toRemove.getAccountlist());
            clList.remove(toRemove);
            saveToFile();
            return true;
        }
        return false;
    }

    public void deposit(String accNo, float amount) {
        Account acc = searchAccount(accNo);
        if (acc == null) throw new IllegalArgumentException("Account not found");
        acc.deposit(amount);
        saveToFile();
    }

    public void withdraw(String accNo, float amount) {
        Account acc = searchAccount(accNo);
        if (acc == null) throw new IllegalArgumentException("Account not found");
        acc.withdraw(amount);
        saveToFile();
    }

    public float totalAmount() {
        float sum = 0;
        for (Account a : acList) sum += a.getAmount();
        return sum;
    }

    public Client searchCustomerDetail(String CNIC) {
        for (Client c : clList) {
            if (c.getPersondetails().getCNIC().equals(CNIC)) return c;
        }
        return null;
    }

    public void saveToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(name + ".dat"))) {
            oos.writeObject(this);
        } catch (Exception e) {}
    }

    public boolean loadFromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(name + ".dat"))) {
            Bank b = (Bank) ois.readObject();
            this.clList = b.clList;
            this.acList = b.acList;
            Client.count = this.clList.size();
            Account.count = this.acList.size();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public String toString() {
        return "Bank: " + name + ", Clients: " + clList.size() + ", Accounts: " + acList.size();
    }
}
