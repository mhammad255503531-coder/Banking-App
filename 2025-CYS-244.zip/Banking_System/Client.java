import java.io.Serializable;
import java.util.ArrayList;

public class Client implements Serializable {
    private String id;
    private Person personDetails;
    private ArrayList<Account> accountList;

    public static int count = 0;

    public Client() {
        this.id = generateClientID();
        this.personDetails = new Person();
        this.accountList = new ArrayList<>();
    }

    public Client(String id, Person personDetails) {
        this.personDetails = (personDetails != null) ? personDetails : new Person();
        this.accountList = new ArrayList<>();

        if (id != null && !id.trim().isEmpty()) {
            this.id = id;
        } else {
            this.id = generateClientID();
        }

        count++;
    }

    private String generateClientID() {
        return "CL" + String.format("%06d", count + 1);
    }

    public String getID() { return id; }
    public Person getPersondetails() { return personDetails; }
    public ArrayList<Account> getAccountlist() { return accountList; }

    public void setID(String id) {
        if (id != null && !id.trim().isEmpty()) this.id = id;
    }

    public void setPersondetails(Person personDetails) {
        if (personDetails != null) this.personDetails = personDetails;
    }

    public void setAccountlist(ArrayList<Account> accountList) {
        if (accountList != null) this.accountList = accountList;
    }

    public void addAccount(Account a) {
        if (a != null) accountList.add(a);
    }

    public void removeAccount(Account a) {
        accountList.remove(a);
    }

    public float totalAmount() {
        float total = 0;
        for (Account a : accountList) total += a.getAmount();
        return total;
    }

    public void withdraw(float amount, String accNo) {
        if (amount <= 0) throw new IllegalArgumentException("Withdrawal amount must be greater than zero.");
        for (Account a : accountList) {
            if (a.getNumber().equals(accNo)) {
                a.withdraw(amount);
                return;
            }
        }
        throw new IllegalArgumentException("Account not found: " + accNo);
    }

    public void deposit(float amount, String accNo) {
        if (amount <= 0) throw new IllegalArgumentException("Deposit amount must be greater than zero.");
        for (Account a : accountList) {
            if (a.getNumber().equals(accNo)) {
                a.deposit(amount);
                return;
            }
        }
        throw new IllegalArgumentException("Account not found: " + accNo);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ID: ").append(id)
                .append(" | ").append(personDetails.toString())
                .append("\nAccounts:");
        if (accountList.isEmpty()) {
            sb.append("\n  No accounts.");
        } else {
            for (Account a : accountList) {
                sb.append("\n  ").append(a.toString());
            }
        }
        return sb.toString();
    }
}
