public class Main
{
    public static void main(String[] args)
    {
        BankGUI.main(args);
    }
}