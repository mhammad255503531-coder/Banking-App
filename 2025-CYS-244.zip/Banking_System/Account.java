import java.io.Serializable;

public class Account implements Serializable {
    private String number;
    private float amount;
    private Client acHolder;

    public static int count = 0;

    public Account() {
        this.amount = 0.0f;
        this.acHolder = null;
        this.number = generateAccountNumber();
        count++;
    }

    public Account(String number, float amount, Client acHolder) {
        this.amount = Math.max(0, amount);
        this.acHolder = acHolder;
        if (number != null && !number.trim().isEmpty()) {
            this.number = number;
        } else {
            this.number = generateAccountNumber();
        }
        count++;
    }

    private String generateAccountNumber() {
        return "AC" + String.format("%06d", count + 1);
    }

    public String getNumber() { return number; }
    public float getAmount() { return amount; }
    public Client getAcHolder() { return acHolder; }

    public void setNumber(String n) {
        if (n != null && !n.trim().isEmpty()) this.number = n;
    }

    public void setAmount(float a) {
        this.amount = Math.max(0, a);
    }

    public void setAcHolder(Client c) {
        this.acHolder = c;
    }

    public float withdraw(float amt) {
        if (amt <= 0) throw new IllegalArgumentException("Withdrawal amount must be greater than zero.");
        if (amt > this.amount) throw new IllegalArgumentException("Insufficient balance! Available: Rs." + String.format("%.2f", this.amount));
        this.amount -= amt;
        return this.amount;
    }

    public float deposit(float amt) {
        if (amt <= 0) throw new IllegalArgumentException("Deposit amount must be greater than zero.");
        this.amount += amt;
        return this.amount;
    }

    @Override
    public String toString() {
        String holderName = (acHolder != null && acHolder.getPersondetails() != null)
                ? acHolder.getPersondetails().getName()
                : "Unknown";
        return "Account No: " + number +
                " | Balance: Rs." + String.format("%.2f", amount) +
                " | Holder: " + holderName;
    }
}
