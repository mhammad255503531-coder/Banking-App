import java.io.Serializable;

public class Person implements Serializable {
    private String name;
    private String cnic;
    private String phoneNo;

    public Person() {
        name = "";
        cnic = "";
        phoneNo = "";
    }

    public Person(String name, String cnic, String phoneNo) {
        this.name = name;
        this.cnic = cnic;
        this.phoneNo = phoneNo;
    }

    public String getName() { return name; }
    public String getCNIC() { return cnic; }
    public String getPhoneNo() { return phoneNo; }

    public void setName(String n) { this.name = n; }
    public void setCNIC(String c) { this.cnic = c; }
    public void setPhoneNo(String p) { this.phoneNo = p; }

    @Override
    public String toString() {
        return "Name: " + name +
                " | CNIC: " + cnic +
                " | Phone: " + phoneNo;
    }
}
